<div class="space-y-3">
    <h2 class="text-lg font-semibold text-slate-900">Category page placeholder</h2>
    <p class="text-sm text-slate-500">Dung de tach page wrappers neu module Category can nhieu man hinh.</p>
    @include('Category::components.placeholder')
</div>